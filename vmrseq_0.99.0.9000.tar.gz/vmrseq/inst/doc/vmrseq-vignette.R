## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "##"
)

## ----installation, eval = FALSE-----------------------------------------------
#  # install.packages("devtools")
#  devtools::install_github("nshen7/vmrseq")

## ----setup, warning=F, message=F----------------------------------------------
# library(vmrseq)
devtools::load_all('..')

## ----vmrseq, fig.retina = NULL, fig.align='center', fig.wide = TRUE, echo=FALSE----
knitr::include_graphics("../man/figures/method.png", dpi = 300)

## ----eval = F-----------------------------------------------------------------
#  data.pool(cellFiles = cell_list, sep = ",", chrNames = "chr1", writeDir = "your/write/path")

## -----------------------------------------------------------------------------
data("cell_1")
head(cell_1)

## -----------------------------------------------------------------------------
toy.se <- HDF5Array::loadHDF5SummarizedExperiment(system.file("extdata", "toy", package = "vmrseq"))

## -----------------------------------------------------------------------------
toy.se

## -----------------------------------------------------------------------------
dim(toy.se)

## -----------------------------------------------------------------------------
GenomicRanges::granges(toy.se)

## -----------------------------------------------------------------------------
SummarizedExperiment::assays(toy.se)

## -----------------------------------------------------------------------------
SummarizedExperiment::assays(toy.se)$M_mat[5:10, 5:10]

## -----------------------------------------------------------------------------
total <- DelayedArray::rowSums(SummarizedExperiment::assays(toy.se)$M_mat > 0)
toy.se <- subset(toy.se, total >= 3)

## -----------------------------------------------------------------------------
dim(toy.se)

## ----eval = F-----------------------------------------------------------------
#  library("BiocParallel")
#  register(MulticoreParam(8))

## -----------------------------------------------------------------------------
gr <- vmrseq.smooth(toy.se)

## -----------------------------------------------------------------------------
head(gr)

## -----------------------------------------------------------------------------
results <- vmrseq.fit(gr)

## -----------------------------------------------------------------------------
results_s1 <- vmrseq.fit(gr, stage1only = TRUE)

## -----------------------------------------------------------------------------
results

## -----------------------------------------------------------------------------
names(results_s1)

## -----------------------------------------------------------------------------
regions.se <- region.summary(SE = toy.se, region_ranges = results$vmr.ranges)
regions.se

## -----------------------------------------------------------------------------
assays(regions.se)$MF[1:5, 1:5]

## -----------------------------------------------------------------------------
MF <- assays(regions.se)$MF
d_mat <- cluster::daisy(t(MF), metric = 'manhattan', stand = FALSE, warnBin = FALSE) %>% as.matrix()

## -----------------------------------------------------------------------------
umap <- uwot::umap(d_mat %>% as("sparseMatrix"), n_neighbors = 15, n_components = 2)

## -----------------------------------------------------------------------------
as.data.frame(umap) %>% 
  ggplot(aes(V1, V2)) +
  geom_point() +
  theme_classic() +
  xlab('UMAP 1') + 
  ylab('UMAP 2')

## -----------------------------------------------------------------------------
sessionInfo()

